import CartDrawer from "@/components/CartDrawer";
import Navbar from "@/components/Navbar";
import { useCart, type Product } from "@/contexts/CartContext";
import { Filter, Search, ShoppingBag, Star, X } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation } from "wouter";
import productsData from "../data/products.json";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663644337479/HNL8R3gCARdS426eKM3bun/hero-banner-fdKxPCs6zBMRanBKc6gvkh.webp";

const allProducts = productsData as Product[];

// Get unique categories
const ALL_CATEGORIES = ["All", ...Array.from(new Set(allProducts.map((p) => p.category))).sort()];

type SortOption = "featured" | "newest" | "price-asc" | "price-desc";

function StarRating({ rating, count }: { rating?: number; count?: number }) {
  if (!rating) return null;
  return (
    <div className="flex items-center gap-1">
      <div className="flex">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`w-3 h-3 ${
              star <= Math.round(rating)
                ? "fill-amber-400 text-amber-400"
                : "fill-stone-200 text-stone-200"
            }`}
          />
        ))}
      </div>
      <span className="text-xs text-stone-500">
        {rating.toFixed(1)} {count ? `(${count})` : ""}
      </span>
    </div>
  );
}

function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const [, navigate] = useLocation();
  const hasDiscount = product.compare_at_price && parseFloat(product.compare_at_price) > parseFloat(product.price);
  const discountPct = hasDiscount
    ? Math.round((1 - parseFloat(product.price) / parseFloat(product.compare_at_price!)) * 100)
    : 0;

  const formatPrice = (p: string) =>
    `KSh ${parseFloat(p).toLocaleString("en-KE", { minimumFractionDigits: 0 })}`;

  return (
    <div className="product-card bg-white rounded-lg overflow-hidden border border-stone-100 flex flex-col group">
      {/* Image */}
      <div
        className="relative overflow-hidden bg-stone-50 aspect-[3/4] cursor-pointer"
        onClick={() => navigate(`/product/${product.handle}`)}
      >
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80";
          }}
        />
        {hasDiscount && (
          <span className="absolute top-2 left-2 bg-red-500 text-white text-[10px] font-bold px-2 py-0.5 rounded">
            -{discountPct}%
          </span>
        )}
        <span className="absolute top-2 right-2 bg-white/90 text-stone-600 text-[10px] font-medium px-2 py-0.5 rounded uppercase tracking-wide">
          {product.category}
        </span>
      </div>

      {/* Info */}
      <div className="p-3 flex flex-col flex-1">
        <button
          onClick={() => navigate(`/product/${product.handle}`)}
          className="text-left"
        >
          <h3 className="font-display text-sm font-medium text-stone-800 leading-tight line-clamp-2 hover:text-primary transition-colors">
            {product.title}
          </h3>
        </button>

        {product.averageRating && (
          <div className="mt-1">
            <StarRating rating={product.averageRating} count={product.totalReviews} />
          </div>
        )}

        <div className="mt-auto pt-2 flex items-center justify-between gap-2">
          <div>
            <span className="font-semibold text-stone-800 text-sm">
              {formatPrice(product.price)}
            </span>
            {hasDiscount && (
              <span className="text-xs text-stone-400 line-through ml-1.5">
                {formatPrice(product.compare_at_price!)}
              </span>
            )}
          </div>
        </div>

        <button
          onClick={() => addToCart(product)}
          className="mt-2 w-full py-2 bg-primary text-primary-foreground rounded text-xs font-medium hover:opacity-90 transition-opacity flex items-center justify-center gap-1.5"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          Add to Cart
        </button>
      </div>
    </div>
  );
}

export default function Home() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState<SortOption>("featured");
  const [showFilters, setShowFilters] = useState(false);
  const [visibleCount, setVisibleCount] = useState(20);
  const loaderRef = useRef<HTMLDivElement>(null);

  // Filter and sort products
  const filtered = useMemo(() => {
    let result = allProducts;

    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    if (category !== "All") {
      result = result.filter((p) => p.category === category);
    }

    switch (sort) {
      case "price-asc":
        result = [...result].sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
        break;
      case "price-desc":
        result = [...result].sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
        break;
      case "newest":
        result = [...result].reverse();
        break;
      default:
        break;
    }

    return result;
  }, [search, category, sort]);

  const visible = filtered.slice(0, visibleCount);

  // Infinite scroll
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && visibleCount < filtered.length) {
          setVisibleCount((c) => Math.min(c + 20, filtered.length));
        }
      },
      { threshold: 0.1 }
    );
    if (loaderRef.current) observer.observe(loaderRef.current);
    return () => observer.disconnect();
  }, [filtered.length, visibleCount]);

  // Reset visible count on filter change
  useEffect(() => {
    setVisibleCount(20);
  }, [search, category, sort]);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <CartDrawer />

      {/* Hero */}
      <section className="relative h-72 md:h-96 overflow-hidden">
        <img
          src={HERO_IMAGE}
          alt="Zia Africa - Sustainable Fashion"
          className="w-full h-full object-cover object-top"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/30 to-transparent" />
        <div className="absolute inset-0 flex flex-col justify-center px-8 md:px-16">
          <p className="text-white/80 text-sm font-body uppercase tracking-widest mb-2">
            Sustainable Fashion
          </p>
          <h1 className="font-display text-4xl md:text-6xl font-light text-white leading-tight">
            African Soul.
          </h1>
          <p className="text-white/70 text-sm mt-3 max-w-xs font-body">
            Timeless designs. Ethical craftsmanship.
          </p>
        </div>
      </section>

      {/* Search & Filter bar */}
      <div className="sticky top-16 z-30 bg-white/95 backdrop-blur-sm border-b border-stone-100 shadow-sm">
        <div className="container py-3 flex items-center gap-3">
          {/* Search */}
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
            <input
              type="text"
              placeholder="Search products..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-8 py-2 text-sm border border-stone-200 rounded-md bg-stone-50 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-colors"
            />
            {search && (
              <button
                onClick={() => setSearch("")}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Filter toggle */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-1.5 px-3 py-2 text-sm border rounded-md transition-colors ${
              showFilters || category !== "All"
                ? "bg-primary text-primary-foreground border-primary"
                : "border-stone-200 text-stone-600 hover:bg-stone-50"
            }`}
          >
            <Filter className="w-3.5 h-3.5" />
            Filter
            {category !== "All" && (
              <span className="bg-white/30 text-xs px-1 rounded">1</span>
            )}
          </button>

          {/* Sort */}
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortOption)}
            className="text-sm border border-stone-200 rounded-md px-3 py-2 bg-white text-stone-700 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
          >
            <option value="featured">Featured</option>
            <option value="newest">Newest</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
        </div>

        {/* Category filter pills */}
        {showFilters && (
          <div className="container pb-3 flex gap-2 overflow-x-auto scrollbar-none">
            {ALL_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`flex-shrink-0 px-3 py-1 text-xs rounded-full border transition-colors ${
                  category === cat
                    ? "bg-primary text-primary-foreground border-primary"
                    : "border-stone-200 text-stone-600 hover:bg-stone-50"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Product grid */}
      <main className="container py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-2xl font-medium text-stone-800">
            {category === "All" ? "All Products" : category}
          </h2>
          <p className="text-sm text-stone-500">
            Showing {visible.length} of {filtered.length} products
          </p>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="font-display text-2xl text-stone-400">No products found</p>
            <p className="text-stone-400 text-sm mt-2">Try adjusting your search or filters</p>
            <button
              onClick={() => { setSearch(""); setCategory("All"); }}
              className="mt-4 px-5 py-2 bg-primary text-primary-foreground rounded text-sm font-medium hover:opacity-90 transition-opacity"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {visible.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        {/* Infinite scroll loader */}
        {visibleCount < filtered.length && (
          <div ref={loaderRef} className="flex justify-center py-8">
            <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-stone-800 text-stone-300 py-10 mt-8">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 bg-primary rounded-sm flex items-center justify-center">
                  <span className="text-white font-display font-bold text-sm">Z</span>
                </div>
                <span className="font-display text-lg font-semibold text-white">ZIA</span>
              </div>
              <p className="text-xs text-stone-400 leading-relaxed">
                Quality, unique and timeless pieces for the aspirational woman.
              </p>
            </div>
            <div>
              <h4 className="font-display text-sm font-semibold text-white mb-3">Shop</h4>
              <ul className="space-y-2 text-xs">
                <li><button onClick={() => setCategory("All")} className="hover:text-white transition-colors">All Products</button></li>
                <li><button onClick={() => setCategory("General")} className="hover:text-white transition-colors">General</button></li>
                <li><button onClick={() => setCategory("Hoodies")} className="hover:text-white transition-colors">Hoodies</button></li>
                <li><button onClick={() => setCategory("Dress")} className="hover:text-white transition-colors">Dresses</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-display text-sm font-semibold text-white mb-3">Help</h4>
              <ul className="space-y-2 text-xs">
                <li><span className="hover:text-white transition-colors cursor-pointer">Contact Us</span></li>
                <li><span className="hover:text-white transition-colors cursor-pointer">Size Chart</span></li>
                <li><span className="hover:text-white transition-colors cursor-pointer">Returns Policy</span></li>
                <li><span className="hover:text-white transition-colors cursor-pointer">Shipping Info</span></li>
              </ul>
            </div>
            <div>
              <h4 className="font-display text-sm font-semibold text-white mb-3">Follow Us</h4>
              <ul className="space-y-2 text-xs">
                <li>
                  <a href="https://instagram.com/ziaafrica" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                    Instagram
                  </a>
                </li>
                <li>
                  <a href="https://facebook.com/ziaafrica" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                    Facebook
                  </a>
                </li>
                <li>
                  <a href="https://youtube.com/ziaafrica" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">
                    YouTube
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-stone-700 pt-6 text-center text-xs text-stone-500">
            © {new Date().getFullYear()} Zia Africa. All rights reserved. Made with love in Kenya.
          </div>
        </div>
      </footer>
    </div>
  );
}
