import CartDrawer from "@/components/CartDrawer";
import Navbar from "@/components/Navbar";
import { useCart } from "@/contexts/CartContext";
import { CheckCircle, ChevronRight, CreditCard, Lock, ShoppingBag, Truck } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

type Step = "information" | "shipping" | "payment" | "confirmation";

interface OrderForm {
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  city: string;
  county: string;
  postalCode: string;
  country: string;
  shippingMethod: "standard" | "express";
  paymentMethod: "mpesa" | "card" | "cod";
  mpesaPhone: string;
  cardNumber: string;
  cardExpiry: string;
  cardCvv: string;
  cardName: string;
}

const SHIPPING_RATES = {
  standard: { label: "Standard Delivery (3–5 days)", price: 350 },
  express: { label: "Express Delivery (1–2 days)", price: 650 },
};

const COUNTIES = [
  "Nairobi", "Mombasa", "Kisumu", "Nakuru", "Eldoret", "Thika",
  "Malindi", "Kitale", "Garissa", "Kakamega", "Nyeri", "Machakos",
  "Meru", "Kisii", "Kericho", "Other",
];

export default function Checkout() {
  const { items, subtotal, clearCart } = useCart();
  const [, navigate] = useLocation();
  const [step, setStep] = useState<Step>("information");
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderNumber, setOrderNumber] = useState("");

  const [form, setForm] = useState<OrderForm>({
    email: "",
    firstName: "",
    lastName: "",
    phone: "",
    address: "",
    city: "",
    county: "Nairobi",
    postalCode: "",
    country: "Kenya",
    shippingMethod: "standard",
    paymentMethod: "mpesa",
    mpesaPhone: "",
    cardNumber: "",
    cardExpiry: "",
    cardCvv: "",
    cardName: "",
  });

  const shipping = SHIPPING_RATES[form.shippingMethod].price;
  const total = subtotal + shipping;

  const formatPrice = (p: number) =>
    `KSh ${p.toLocaleString("en-KE", { minimumFractionDigits: 0 })}`;

  const update = (field: keyof OrderForm, value: string) =>
    setForm((f) => ({ ...f, [field]: value }));

  const handlePlaceOrder = async () => {
    setIsProcessing(true);
    // Simulate payment processing
    await new Promise((r) => setTimeout(r, 2000));
    const num = `ZIA-${Date.now().toString(36).toUpperCase()}`;
    setOrderNumber(num);
    clearCart();
    setStep("confirmation");
    setIsProcessing(false);
  };

  const steps: { id: Step; label: string }[] = [
    { id: "information", label: "Information" },
    { id: "shipping", label: "Shipping" },
    { id: "payment", label: "Payment" },
  ];

  const currentStepIdx = steps.findIndex((s) => s.id === step);

  if (items.length === 0 && step !== "confirmation") {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <CartDrawer />
        <div className="container py-20 text-center">
          <ShoppingBag className="w-16 h-16 text-stone-200 mx-auto mb-4" />
          <h1 className="font-display text-3xl text-stone-600">Your cart is empty</h1>
          <p className="text-stone-400 mt-2">Add some products before checking out</p>
          <button
            onClick={() => navigate("/")}
            className="mt-6 px-6 py-2.5 bg-primary text-primary-foreground rounded font-medium hover:opacity-90 transition-opacity"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  if (step === "confirmation") {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <CartDrawer />
        <div className="container py-16 max-w-2xl mx-auto text-center">
          <div className="bg-white rounded-2xl p-10 shadow-sm border border-stone-100">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h1 className="font-display text-3xl font-medium text-stone-800 mb-2">
              Order Confirmed!
            </h1>
            <p className="text-stone-500 mb-1">
              Thank you, {form.firstName}! Your order has been placed.
            </p>
            <p className="text-sm text-stone-400 mb-6">
              Order number: <span className="font-mono font-semibold text-stone-700">{orderNumber}</span>
            </p>
            <div className="bg-stone-50 rounded-xl p-4 text-left mb-6">
              <p className="text-sm font-medium text-stone-700 mb-1">Delivery details</p>
              <p className="text-sm text-stone-500">
                {form.address}, {form.city}, {form.county}
              </p>
              <p className="text-sm text-stone-500">{SHIPPING_RATES[form.shippingMethod].label}</p>
            </div>
            <p className="text-xs text-stone-400 mb-6">
              A confirmation will be sent to <strong>{form.email}</strong>
            </p>
            <button
              onClick={() => navigate("/")}
              className="w-full py-3.5 bg-primary text-primary-foreground rounded font-medium hover:opacity-90 transition-opacity"
            >
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <CartDrawer />

      <div className="container py-8 max-w-6xl mx-auto">
        {/* Breadcrumb steps */}
        <div className="flex items-center gap-2 mb-8 text-sm">
          {steps.map((s, i) => (
            <div key={s.id} className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (i < currentStepIdx) setStep(s.id);
                }}
                className={`font-medium transition-colors ${
                  s.id === step
                    ? "text-primary"
                    : i < currentStepIdx
                    ? "text-stone-600 hover:text-primary"
                    : "text-stone-300"
                }`}
              >
                {s.label}
              </button>
              {i < steps.length - 1 && (
                <ChevronRight className="w-4 h-4 text-stone-300" />
              )}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-[1fr_380px] gap-10">
          {/* Left: Form */}
          <div className="space-y-6">
            {/* INFORMATION STEP */}
            {step === "information" && (
              <div className="bg-white rounded-xl p-6 border border-stone-100 shadow-sm">
                <h2 className="font-display text-xl font-medium text-stone-800 mb-5">
                  Contact Information
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-stone-700 block mb-1">
                      Email address *
                    </label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => update("email", e.target.value)}
                      placeholder="your@email.com"
                      className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-stone-700 block mb-1">
                      Phone number *
                    </label>
                    <input
                      type="tel"
                      value={form.phone}
                      onChange={(e) => update("phone", e.target.value)}
                      placeholder="+254 700 000 000"
                      className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        First name *
                      </label>
                      <input
                        type="text"
                        value={form.firstName}
                        onChange={(e) => update("firstName", e.target.value)}
                        className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        Last name *
                      </label>
                      <input
                        type="text"
                        value={form.lastName}
                        onChange={(e) => update("lastName", e.target.value)}
                        className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                      />
                    </div>
                  </div>
                </div>

                <h2 className="font-display text-xl font-medium text-stone-800 mt-8 mb-5">
                  Delivery Address
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-stone-700 block mb-1">
                      Street address *
                    </label>
                    <input
                      type="text"
                      value={form.address}
                      onChange={(e) => update("address", e.target.value)}
                      placeholder="House/Apartment number, Street name"
                      className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        City / Town *
                      </label>
                      <input
                        type="text"
                        value={form.city}
                        onChange={(e) => update("city", e.target.value)}
                        className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        County *
                      </label>
                      <select
                        value={form.county}
                        onChange={(e) => update("county", e.target.value)}
                        className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                      >
                        {COUNTIES.map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        Postal code
                      </label>
                      <input
                        type="text"
                        value={form.postalCode}
                        onChange={(e) => update("postalCode", e.target.value)}
                        className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        Country
                      </label>
                      <input
                        type="text"
                        value={form.country}
                        readOnly
                        className="w-full px-3 py-2.5 text-sm border border-stone-100 rounded-md bg-stone-50 text-stone-500"
                      />
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setStep("shipping")}
                  disabled={!form.email || !form.firstName || !form.lastName || !form.address || !form.city}
                  className="mt-6 w-full py-3.5 bg-primary text-primary-foreground rounded font-medium text-sm hover:opacity-90 transition-opacity disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  Continue to Shipping
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* SHIPPING STEP */}
            {step === "shipping" && (
              <div className="bg-white rounded-xl p-6 border border-stone-100 shadow-sm">
                <h2 className="font-display text-xl font-medium text-stone-800 mb-5">
                  Shipping Method
                </h2>
                <div className="space-y-3">
                  {(Object.entries(SHIPPING_RATES) as [string, { label: string; price: number }][]).map(
                    ([key, val]) => (
                      <label
                        key={key}
                        className={`flex items-center justify-between p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                          form.shippingMethod === key
                            ? "border-primary bg-primary/5"
                            : "border-stone-200 hover:border-stone-300"
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="radio"
                            name="shipping"
                            value={key}
                            checked={form.shippingMethod === key as "standard" | "express"}
                            onChange={() => update("shippingMethod", key)}
                            className="accent-primary"
                          />
                          <div>
                            <p className="text-sm font-medium text-stone-800">{val.label}</p>
                            <p className="text-xs text-stone-500 flex items-center gap-1 mt-0.5">
                              <Truck className="w-3 h-3" />
                              Delivered to your door
                            </p>
                          </div>
                        </div>
                        <span className="text-sm font-semibold text-stone-700">
                          {formatPrice(val.price)}
                        </span>
                      </label>
                    )
                  )}
                </div>

                <div className="flex gap-3 mt-6">
                  <button
                    onClick={() => setStep("information")}
                    className="flex-1 py-3 border border-stone-200 text-stone-600 rounded font-medium text-sm hover:bg-stone-50 transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => setStep("payment")}
                    className="flex-1 py-3 bg-primary text-primary-foreground rounded font-medium text-sm hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
                  >
                    Continue to Payment
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* PAYMENT STEP */}
            {step === "payment" && (
              <div className="bg-white rounded-xl p-6 border border-stone-100 shadow-sm">
                <div className="flex items-center gap-2 mb-5">
                  <Lock className="w-4 h-4 text-green-500" />
                  <h2 className="font-display text-xl font-medium text-stone-800">
                    Secure Payment
                  </h2>
                </div>

                {/* Payment method selection */}
                <div className="space-y-3 mb-6">
                  {[
                    { id: "mpesa", label: "M-Pesa", desc: "Pay via M-Pesa mobile money" },
                    { id: "card", label: "Credit / Debit Card", desc: "Visa, Mastercard, Amex" },
                    { id: "cod", label: "Cash on Delivery", desc: "Pay when you receive your order" },
                  ].map((pm) => (
                    <label
                      key={pm.id}
                      className={`flex items-center gap-3 p-4 rounded-lg border-2 cursor-pointer transition-colors ${
                        form.paymentMethod === pm.id
                          ? "border-primary bg-primary/5"
                          : "border-stone-200 hover:border-stone-300"
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        value={pm.id}
                        checked={form.paymentMethod === pm.id as "mpesa" | "card" | "cod"}
                        onChange={() => update("paymentMethod", pm.id)}
                        className="accent-primary"
                      />
                      <div>
                        <p className="text-sm font-medium text-stone-800">{pm.label}</p>
                        <p className="text-xs text-stone-500">{pm.desc}</p>
                      </div>
                    </label>
                  ))}
                </div>

                {/* M-Pesa fields */}
                {form.paymentMethod === "mpesa" && (
                  <div className="bg-green-50 border border-green-100 rounded-lg p-4 mb-4">
                    <p className="text-sm font-medium text-green-800 mb-3">M-Pesa Details</p>
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        M-Pesa phone number *
                      </label>
                      <input
                        type="tel"
                        value={form.mpesaPhone}
                        onChange={(e) => update("mpesaPhone", e.target.value)}
                        placeholder="e.g. 0712 345 678"
                        className="w-full px-3 py-2.5 text-sm border border-green-200 rounded-md bg-white focus:outline-none focus:ring-2 focus:ring-green-300"
                      />
                    </div>
                    <p className="text-xs text-green-600 mt-2">
                      You will receive an STK push to complete payment.
                    </p>
                  </div>
                )}

                {/* Card fields */}
                {form.paymentMethod === "card" && (
                  <div className="space-y-4 mb-4">
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        Cardholder name *
                      </label>
                      <input
                        type="text"
                        value={form.cardName}
                        onChange={(e) => update("cardName", e.target.value)}
                        placeholder="Name as on card"
                        className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-stone-700 block mb-1">
                        Card number *
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          value={form.cardNumber}
                          onChange={(e) => {
                            const v = e.target.value.replace(/\D/g, "").slice(0, 16);
                            update("cardNumber", v.replace(/(.{4})/g, "$1 ").trim());
                          }}
                          placeholder="1234 5678 9012 3456"
                          maxLength={19}
                          className="w-full pl-3 pr-10 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                        />
                        <CreditCard className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-stone-700 block mb-1">
                          Expiry date *
                        </label>
                        <input
                          type="text"
                          value={form.cardExpiry}
                          onChange={(e) => {
                            const v = e.target.value.replace(/\D/g, "").slice(0, 4);
                            update("cardExpiry", v.length > 2 ? `${v.slice(0, 2)}/${v.slice(2)}` : v);
                          }}
                          placeholder="MM/YY"
                          maxLength={5}
                          className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-stone-700 block mb-1">
                          CVV *
                        </label>
                        <input
                          type="text"
                          value={form.cardCvv}
                          onChange={(e) => update("cardCvv", e.target.value.replace(/\D/g, "").slice(0, 4))}
                          placeholder="123"
                          maxLength={4}
                          className="w-full px-3 py-2.5 text-sm border border-stone-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {form.paymentMethod === "cod" && (
                  <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 mb-4">
                    <p className="text-sm text-amber-800">
                      Pay in cash when your order is delivered. Our delivery agent will collect payment.
                    </p>
                  </div>
                )}

                <div className="flex gap-3 mt-2">
                  <button
                    onClick={() => setStep("shipping")}
                    className="flex-1 py-3 border border-stone-200 text-stone-600 rounded font-medium text-sm hover:bg-stone-50 transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={handlePlaceOrder}
                    disabled={isProcessing}
                    className="flex-1 py-3 bg-primary text-primary-foreground rounded font-medium text-sm hover:opacity-90 transition-opacity disabled:opacity-60 flex items-center justify-center gap-2"
                  >
                    {isProcessing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        Place Order — {formatPrice(total)}
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Right: Order summary */}
          <div className="lg:sticky lg:top-24 h-fit">
            <div className="bg-white rounded-xl p-6 border border-stone-100 shadow-sm">
              <h3 className="font-display text-lg font-medium text-stone-800 mb-4">
                Order Summary
              </h3>

              <ul className="space-y-3 mb-4">
                {items.map(({ product, quantity }) => (
                  <li key={product.id} className="flex gap-3">
                    <div className="relative w-14 h-16 flex-shrink-0 rounded overflow-hidden bg-stone-50">
                      <img
                        src={product.image}
                        alt={product.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=200&q=80";
                        }}
                      />
                      <span className="absolute -top-1 -right-1 bg-stone-600 text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                        {quantity}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-stone-700 line-clamp-2 leading-tight">
                        {product.title}
                      </p>
                      <p className="text-xs text-stone-400 mt-0.5">{product.category}</p>
                    </div>
                    <p className="text-xs font-semibold text-stone-700 flex-shrink-0">
                      {formatPrice(parseFloat(product.price) * quantity)}
                    </p>
                  </li>
                ))}
              </ul>

              <div className="border-t border-stone-100 pt-4 space-y-2">
                <div className="flex justify-between text-sm text-stone-600">
                  <span>Subtotal</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm text-stone-600">
                  <span>Shipping</span>
                  <span>{formatPrice(shipping)}</span>
                </div>
                <div className="flex justify-between font-semibold text-stone-800 pt-2 border-t border-stone-100">
                  <span className="font-display text-base">Total</span>
                  <span className="font-display text-base">{formatPrice(total)}</span>
                </div>
              </div>

              <div className="mt-4 flex items-center gap-1.5 text-xs text-stone-400">
                <Lock className="w-3 h-3" />
                Secure checkout powered by SSL encryption
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer className="bg-stone-800 text-stone-400 py-6 text-center text-xs mt-8">
        © {new Date().getFullYear()} Zia Africa. All rights reserved.
      </footer>
    </div>
  );
}
